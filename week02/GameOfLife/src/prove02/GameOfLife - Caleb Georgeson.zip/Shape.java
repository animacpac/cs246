package prove02;

/**
 * Shapes that can be used to draw creatures.
 * @see Creature
 */
public enum Shape {
	Circle, Square, Star;
}